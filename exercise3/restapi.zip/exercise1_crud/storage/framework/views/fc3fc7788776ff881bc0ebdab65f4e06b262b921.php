
<?php $__env->startSection('main'); ?>
<!-- <?php echo $__env->make('routers.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
<div class="row">
<div class="col-sm-12">
    <?php if(session()->get('success')): ?>
        <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>  
        </div>
    <?php endif; ?>
    <h1 class="display-3">All Routers Information</h1>    
    <table class="table table-striped">
    <div>
    <a style="margin: 19px;" href="<?php echo e(route('routers.create')); ?>" class="btn btn-primary">Add New Router</a>
    </div>
    <thead>
        <tr>
          <td>SAP ID</td>
          <td>Hostname</td>
          <td>Loopback(IPv4)</td>
          <td>MAC Address</td>
          <td>Type</td>
          <td colspan = 2>Actions</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $routers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $router): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($router->sap_id); ?></td>
            <td><?php echo e($router->hostname); ?></td>
            <td><?php echo e($router->loopback); ?></td>
            <td><?php echo e($router->mac_address); ?></td>
            <td><?php echo e($router->type); ?></td>
            <td>
                <a href="<?php echo e(route('routers.edit',$router->id)); ?>" class="btn btn-primary">Edit</a>
            </td>
            <td>
                <form action="<?php echo e(route('routers.destroy', $router->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exercise1_crud\resources\views/routers/index.blade.php ENDPATH**/ ?>