<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\Router; 
use DB;
// use Illuminate\Support\Facades\Auth; 
use Validator;

class RouterAPIController extends Controller 
{

    /** 
     * Create api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function createRouter(Request $request) {
        $router = new Router;
        $router->sap_id = $request->sap_id;
        $router->hostname = $request->hostname;
        $router->loopback = $request->loopback;
        $router->mac_address = $request->mac_address;
        
        $router->type = $request->type;

        $router->save();
    
        return response()->json([
            "message" => "router record created"
        ], 201);
    }

    /** 
     * update api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function updateRouterUsingIP(Request $request, $ip) 
    { 
        $routers = DB::table('routers')->where('loopback','LIKE',$ip)->update(['sap_id' => $request->sap_id, 
        'mac_address' => $request->mac_address ]);
        return response()->json([
            "details" => $routers
        ], 201);
        
    } 

    /** 
     * range api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function rangeRouterUsingIP(Request $request, $ip){
        $ip_arr = explode('&=',$ip);
        $max_ip = ip2long($ip_arr[0]);
        $min_ip = ip2long($ip_arr[1]);
        $range = DB::table('routers')->whereBetween('loopback',[$min_ip, $max_ip])->get();
        return response()->json([
            "details" => $ip_arr
        ], 201);
    }
    
    /** 
     * Delete api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function deleteRouterUsingIP(Request $request, $ip) 
    { 
        $routers = DB::table('routers')->where('loopback','LIKE',$ip)->delete();
        return response()->json([
            "details" => $routers
        ], 201);
        
    } 
   
   
    /** 
     * list api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function listRouterUsingSapID(Request $request, $sap_id) 
    { 
        $routers = DB::table('routers')->where('sap_id','LIKE',$sap_id)->get();
        return response()->json([
            "details" => $routers
        ], 201);
        
    } 

}